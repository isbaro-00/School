# Complete Project

This Flutter source archive retains the app screens and navigation but no longer depends on Supabase. A local in-memory compatibility layer allows the app to run as an offline demo.

Data does not persist after app restart; use a secure persistent backend for production.
