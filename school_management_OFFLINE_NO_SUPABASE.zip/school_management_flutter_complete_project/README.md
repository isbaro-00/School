# School Management System

Flutter school-management app with the existing screens and navigation preserved. This archive has been detached from Supabase and runs in offline demo mode.

## Important
- No Supabase URL, keys, migrations, SQL scripts, or Edge Functions are included.
- Demo data is stored only in memory and resets when the app restarts.
- Offline demo authentication is not secure and must not be used for real accounts.
- Real multi-school deployment requires a persistent backend and secure authentication.

## Build
Run `flutter pub get`, then `flutter run`. To build an APK, run `flutter build apk --release`.
