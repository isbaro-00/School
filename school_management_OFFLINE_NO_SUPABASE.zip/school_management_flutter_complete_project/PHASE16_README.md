# Project note

This source package runs in offline demo mode and does not require Supabase. Data is held in memory and resets when the app restarts. For real multi-school use, connect a secure persistent backend before deployment.
