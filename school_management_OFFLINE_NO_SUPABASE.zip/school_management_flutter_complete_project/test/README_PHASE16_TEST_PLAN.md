# Test plan

Run Flutter unit and widget tests with `flutter test`. The app uses offline demo storage; data resets on restart. Do not use demo authentication for real accounts.
