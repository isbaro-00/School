# Security checklist

- Offline demo login is not production authentication.
- Add secure server-side authorization before using real student or payment data.
- Never store passwords in plain text.
