import 'dart:async';

/// Offline in-memory compatibility layer. Data resets when the app restarts.
class LocalAuthUser {
  final String id;
  final String email;
  LocalAuthUser(this.id, this.email);
}

class AuthResponse {
  final LocalAuthUser? user;
  AuthResponse({this.user});
}

class AuthException implements Exception {
  final String message;
  AuthException(this.message);
  @override
  String toString() => message;
}

class OfflineBackend {
  static final OfflineBackend instance = OfflineBackend._();
  OfflineBackend._();
  final LocalBackendClient client = LocalBackendClient();
}

class LocalBackendClient {
  final Map<String, List<Map<String, dynamic>>> _tables = {};
  final LocalAuth auth = LocalAuth();
  final LocalFunctions functions = LocalFunctions();
  LocalQuery from(String table) => LocalQuery(_tables, table);
}

class LocalAuth {
  LocalAuthUser? currentUser;
  Future<AuthResponse> signInWithPassword({required String email, required String password}) async {
    if (email.trim().isEmpty || password.isEmpty) throw AuthException('Enter your email and password.');
    currentUser = LocalAuthUser(email.trim().toLowerCase(), email.trim());
    return AuthResponse(user: currentUser);
  }
  Future<void> signOut() async { currentUser = null; }
}

class LocalFunctions {
  Future<LocalFunctionResponse> invoke(String name, {Map<String, dynamic>? body}) async {
    final data = <String, dynamic>{
      'id': DateTime.now().microsecondsSinceEpoch.toString(),
      'school_id': 'offline-school',
      'role': body?['account_type'] ?? 'school_admin',
      'name': body?['identifier'] ?? 'Offline User',
      'auth_login_email': '${(body?['identifier'] ?? 'user').toString().replaceAll(RegExp(r'[^a-zA-Z0-9]'), '').toLowerCase()}@offline.local',
    };
    return LocalFunctionResponse(data);
  }
}
class LocalFunctionResponse { final dynamic data; LocalFunctionResponse(this.data); }

class LocalQuery {
  final Map<String, List<Map<String, dynamic>>> _tables;
  final String table;
  String? _singleMode;
  final List<bool Function(Map<String, dynamic>)> _filters = [];
  final List<MapEntry<String, bool>> _orders = [];
  Map<String, dynamic>? _pending;
  String _operation = 'select';
  LocalQuery(this._tables, this.table);
  List<Map<String, dynamic>> get _rows => _tables.putIfAbsent(table, () => []);
  LocalQuery select([String columns = '*']) => this;
  LocalQuery insert(Map<String, dynamic> values) { _operation = 'insert'; _pending = Map<String, dynamic>.from(values); return this; }
  LocalQuery update(Map<String, dynamic> values) { _operation = 'update'; _pending = Map<String, dynamic>.from(values); return this; }
  LocalQuery upsert(Map<String, dynamic> values, {String? onConflict}) { _operation = 'upsert'; _pending = Map<String, dynamic>.from(values); return this; }
  LocalQuery delete() { _operation = 'delete'; return this; }
  LocalQuery eq(String key, dynamic value) { _filters.add((r) => r[key]?.toString() == value?.toString()); return this; }
  LocalQuery neq(String key, dynamic value) { _filters.add((r) => r[key]?.toString() != value?.toString()); return this; }
  LocalQuery gte(String key, dynamic value) { _filters.add((r) => (r[key]?.toString() ?? '').compareTo(value.toString()) >= 0); return this; }
  LocalQuery lte(String key, dynamic value) { _filters.add((r) => (r[key]?.toString() ?? '').compareTo(value.toString()) <= 0); return this; }
  LocalQuery order(String key, {bool ascending = true}) { _orders.add(MapEntry(key, ascending)); return this; }
  LocalQuery limit(int count) => this;
  LocalQuery maybeSingle() { _singleMode = 'maybe'; return this; }
  LocalQuery single() { _singleMode = 'single'; return this; }
  List<Map<String, dynamic>> _matching() => _rows.where((r) => _filters.every((f) => f(r))).toList();
  dynamic _execute() {
    if (_operation == 'insert' && _pending != null) {
      final row = Map<String, dynamic>.from(_pending!);
      row.putIfAbsent('id', () => DateTime.now().microsecondsSinceEpoch.toString());
      row.putIfAbsent('created_at', () => DateTime.now().toIso8601String());
      _rows.add(row); return _singleMode == 'single' ? row : [row];
    }
    if (_operation == 'upsert' && _pending != null) {
      final row = Map<String, dynamic>.from(_pending!); row.putIfAbsent('id', () => DateTime.now().microsecondsSinceEpoch.toString());
      _rows.add(row); return [row];
    }
    final matches = _matching();
    if (_operation == 'update' && _pending != null) { for (final r in matches) { r.addAll(_pending!); } return matches; }
    if (_operation == 'delete') { _rows.removeWhere((r) => _filters.every((f) => f(r))); return null; }
    for (final o in _orders.reversed) { matches.sort((a,b) { final c = (a[o.key]?.toString() ?? '').compareTo(b[o.key]?.toString() ?? ''); return o.value ? c : -c; }); }
    if (_singleMode == 'maybe') return matches.isEmpty ? null : matches.first;
    if (_singleMode == 'single') { if (matches.isEmpty) return <String, dynamic>{'id': DateTime.now().microsecondsSinceEpoch.toString()}; return matches.first; }
    return matches;
  }
  Future<R> then<R>(FutureOr<R> Function(dynamic) onValue, {Function? onError}) => Future<dynamic>.value(_execute()).then(onValue, onError: onError);
}
