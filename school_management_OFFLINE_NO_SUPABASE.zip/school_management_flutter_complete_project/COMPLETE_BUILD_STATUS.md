# Build Status

Supabase integration has been removed from this source package. The Flutter project uses an offline in-memory demo layer. Verify with `flutter pub get` and `flutter analyze` before publishing.
